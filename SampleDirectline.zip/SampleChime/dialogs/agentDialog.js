// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { TimexProperty } = require('@microsoft/recognizers-text-data-types-timex-expression');
const { InputHints, MessageFactory } = require('botbuilder');
const { ConfirmPrompt, TextPrompt, WaterfallDialog, DialogTurnStatus } = require('botbuilder-dialogs');
const { CancelAndHelpDialog } = require('./cancelAndHelpDialog');
const { DateResolverDialog } = require('./dateResolverDialog');
const { DirectLineSession } = require('../chime/directlineSession');

const CONFIRM_PROMPT = 'confirmPrompt';
const DATE_RESOLVER_DIALOG = 'dateResolverDialog';
const TEXT_PROMPT = 'textPrompt';
const WATERFALL_DIALOG = 'waterfallDialog';

class AgentDialog extends CancelAndHelpDialog {
    constructor(id) {
        super(id || 'AgentDialog');

        this.addDialog(new TextPrompt(TEXT_PROMPT))
            .addDialog(new ConfirmPrompt(CONFIRM_PROMPT))
            .addDialog(new DateResolverDialog(DATE_RESOLVER_DIALOG))
            .addDialog(new WaterfallDialog(WATERFALL_DIALOG, [
                this.firstStep.bind(this),
                this.finalStep.bind(this)
            ]));

        this.initialDialogId = WATERFALL_DIALOG;
        this._botSession;
    }

    async firstStep(stepContext) {
        if(!stepContext.options.isTransferred)
        {
            var chimeSecret = process.env.ChimeSecret;    
            this._botSession = new DirectLineSession(stepContext, stepContext.context, chimeSecret,this.handoffDataAccessor);
            await this._botSession.start();
            await this._botSession.sendMessage(stepContext.context.activity);
        }
        return await { status: DialogTurnStatus.waiting };
        
    }

    /**
     * Complete the interaction and end the dialog.
     */
    async finalStep(stepContext) {
        await this._botSession.sendMessage(stepContext.context.activity);
        
        // Looping until agent is talking
        return await stepContext.replaceDialog(this.initialDialogId, { isTransferred: true });
        
    }

}

module.exports.AgentDialog = AgentDialog;
