

const { TurnContext, MessageFactory, ActivityTypes, ChannelAccount, RoleTypes, TestAdapter } = require('botbuilder');
const { DirectLine } = require ('botframework-directlinejs');
// For Node.js:
// const { DirectLine } = require('botframework-directlinejs');
global.XMLHttpRequest = require('xhr2');
global.WebSocket = require('ws');

const { v4 } =  require('uuid');

class DirectLineSession{
    
    
    constructor(stepContext, context, secret, handoffDataAccessor)
    {
        this._guid = v4()
        this._context = context;
        this._secret = secret;
        this._stepContext = stepContext;
        this._conversationReference = TurnContext.getConversationReference(context.activity);
        this._adapter = context.adapter;
        this._handoffDataAccessor = handoffDataAccessor;
        this._endOfConversation = false; // Initialize
        this._from =  { id: this._guid, name: context.activity.from.name , role:'user'}
        
        if (this._secret == null)
        {
            throw new ArgumentException("Bot Secret is null", nameof(_secret));
        }
        

    }
    async start()
    {
        this.directLine = new DirectLine({
            secret: this._secret,
            
            conversationStartProperties: { /* optional: properties to send to the bot on conversation start */
                locale: 'en-US'
            }
        });
        this.directLine.startConversation();
        this.directLine.activity$
        .subscribe(
            activity => {
                
                this._adapter.continueConversation(this._conversationReference, async turnContext => {
                    var newActivity = {
                        text: activity.text,
                        type: activity.type,
                        attachments:activity.attachments,
                        attachmentLayout:activity.attachmentLayout,
                        value:activity.value,
                    }
                    turnContext.sendActivity(newActivity);
                });
                var sActivity = JSON.stringify(activity); 
                if(sActivity.indexOf('feedback') >=0 )
                {
                    
                    this._adapter.continueConversation(this._conversationReference, async turnContext => {
                        var newActivity = {
                            name:'Chime',
                            type: ActivityTypes.Event,
                            value:'Success',
                        }
                        turnContext.sendActivity(newActivity);
                    });
                }
                console.log("received activity ", activity)
            }
        );
        
    }
    async sendMessage(activity)
    {
        
        this.directLine.postActivity({
            from : { id: this._guid, name : 'User'},
            text: activity.text,
            type: activity.type,
            attachments: activity.attachments,
            attachmentLayout: activity.attachmentLayout,
            value: activity.value,
            channelData :{
                "email" : "foo@bar.com", 
                "skillTags" :  "printer"
            },
        }).subscribe(
            id => console.log("Posted activity, assigned ID ", id),
            error => console.log("Error posting activity", error)
        );
    }
}

module.exports.DirectLineSession = DirectLineSession;